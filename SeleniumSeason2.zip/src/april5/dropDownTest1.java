package april5;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class dropDownTest1 {

	public static void main(String[] args) {
		
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();
		
		driver.get("https://www.amazon.com/");
		driver.manage().window().maximize();
		
		WebElement dropdown= driver.findElement(By.xpath("//select[@id='searchDropdownBox']"));
        List<WebElement> allItems =dropdown.findElements(By.tagName("option"));
        
        System.out.println("All items in the drop down "+ allItems.size());
        
        //For each loop
        
        for(WebElement item:allItems)
        {
        	System.out.println(item.getText());
        }
		
     driver.quit();
	}

}
