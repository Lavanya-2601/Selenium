package april4;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class linkTextDemo1 {

	public static void main(String[] args) {
		
		
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();
		
		driver.get("https://adactinhotelapp.com/");
		driver.manage().window().maximize();
		
		//for all the links common tag name is 'a'so we r choosing tagname
		//for the FindElements(by) return type is list of web elements
		
		List<WebElement> allLinks= driver.findElements(By.tagName("a"));
		
		System.out.println("No of links"+allLinks.size());
		
		for(int i=0;i<allLinks.size();i++)
		{
			System.out.println(allLinks.get(i).getText());
		}
	 driver.quit();
		
	}

}
