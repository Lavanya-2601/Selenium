package april4;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Assignment {

	public static void main(String[] args) {
		
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();
		
		driver.get("https://www.pepperfry.com/");
		driver.manage().window().maximize();
		
		WebElement w1=driver.findElement(By.xpath("//p[text()='Partner With Us']/parent::div"));
		
		//findElements- list of web element
		List<WebElement> allLinks=w1.findElements(By.tagName("div"));
		System.out.println("List of all links "+ allLinks.size());
		
		//Array will start from index=0
		
		for(int i=0;i<allLinks.size();i++)
		{
			System.out.println(allLinks.get(i).getText());
		}
		
		driver.quit();
		
	}

}
