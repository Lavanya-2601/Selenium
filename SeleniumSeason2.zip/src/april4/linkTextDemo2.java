package april4;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class linkTextDemo2 {

	public static void main(String[] args) {
		
		
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();
		
		driver.get("https://www.amazon.com/");
		driver.manage().window().maximize();
		
		//this is just findElement so the return type is Web Element. 
		//We have to focus on the element so we writing here for focusing on the element of that particular module
		
		WebElement block= driver.findElement(By.xpath("//div[text()='Make Money with Us']/parent::div"));
		
		//After focusiing on the element, we are getting all the links which r present in that particular module
		
		//for the FindElements(by) return type is list of web elements
		
		List<WebElement> allLinks =block.findElements(By.tagName("a"));
		
		System.out.println("No of links"+allLinks.size());
		
		for(int i=0;i<allLinks.size();i++)
		{
			System.out.println(allLinks.get(i).getText());
		}
	 driver.quit();
		
	}

}
