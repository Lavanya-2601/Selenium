package feb17;

public class Clock {
	
	//Polymorphism example
	
	int hr,min,sec;
	
	public void m1(int hr)
	{
		this.hr=hr;
	}
	public void m1(int hr, int min)
	{
		this.hr=hr;
		this.min=min;
	}
	public void m1(int hr, int min, int sec)
	{
		this.hr=hr;
		this.min=min;
		this.sec=sec;
	}

	 public void m2()
	 {
		 //System.out.println(hr+":"+min+":"+sec);
		 //If we want to print the time in the format 00:00:00, we have to use printf of format classes
		 System.out.printf("%02d:%02d:%02d",hr,min,sec);
	 }
}
