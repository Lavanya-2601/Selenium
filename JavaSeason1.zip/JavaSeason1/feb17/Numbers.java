package feb17;

public class Numbers {
	
	private int x,y;
	
	//Setters
	
	/*public void setXY(int a,int b)
	{
		It will assign the values of a&b to x&y
		x=a;
		y=b;
	output for this is 10 &20
		
	}*/
	
	/* public void setXY(int x, int y)
    {
    	 Here the value of x&y is the values which comes from the instance variables.
    	 Instance variables default value is 0. Local variables values is considered as a high priority.
    	So the values of x&y is again replaces with 10&20. But the values gets copllapsed at the end of method execution 
    	output for this is 0&0
    	 x=x;
    	 y=y;
	
}*/
	public void setXY(int x, int y)
	{
	  this.x=x;
	  this.y=y;
	  
	  //Here this keyword or operator is used to represent the instance variables.o/p is 10&20
	}
   
	//getters
	public void getXY() 
	{
		System.out.println("Value of x is" +x);
		System.out.println("value of y is" +y);
	}
}
