package feb17;

public class NumbersMain {

	public static void main(String[] args) {
		 Numbers n1=new Numbers();
		 //System.out.println(n1.x);
		 n1.setXY(10, 20);
		 n1.getXY();
		 

	}

}
