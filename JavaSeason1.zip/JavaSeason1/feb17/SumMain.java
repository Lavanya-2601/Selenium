package feb17;

public class SumMain {

	public static void main(String[] args) {
		
		Sum S1=new Sum();
		/*S1.add(10, 20);
		S1.addDouble(10.32, 20.45);
		S1.addLong(5666778784l, 6537632383l);*/

		S1.add(10, 20);
		S1.add(10.32, 20.45);
		S1.add(5666778784l, 6537632383l);
		S1.add(10, 20, 30);

	}

}
