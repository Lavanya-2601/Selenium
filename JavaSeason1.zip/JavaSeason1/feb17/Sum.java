package feb17;

public class Sum {
	//Polymorphisam
	
	/*Here we r using multiple methods for performimng the same operations.This is without polymorphism
	
	
	public void add(int x, int y)
	{
		System.out.println("Sum is "+(x+y));
	}
	public void addDouble(double x, double y)
	{
		System.out.println("Sum is "+(x+y));
	}
	public void addLong(long x, long y)
	{
		System.out.println("Sum is "+(x+y));
	}*/

	
	//Here we r using single method with different parameters for performimng the same operations.This is with polymorphism
	
	
		public void add(int x, int y)
		{
			System.out.println("Sum is "+(x+y));
		}
		public void add(double x, double y)
		{
			System.out.println("Sum is "+(x+y));
		}
		public void add(long x, long y)
		{
			System.out.println("Sum is "+(x+y));
		}
		public void add(int x, int y, int z)
		{
			System.out.println("Sum is "+(x+y+z));
		}


}
