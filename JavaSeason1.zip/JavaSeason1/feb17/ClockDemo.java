package feb17;

public class ClockDemo {

	public static void main(String[] args) {
		
		 Clock c1=new Clock();
		 
		 c1.m1(7);
		 //c1.m2();
		 
		 c1.m1(6, 30);
		 c1.m2();

	}

}
