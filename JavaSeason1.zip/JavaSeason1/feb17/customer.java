package feb17;

public class customer {

	public static void main(String[] args) {
		Bank b1=new Bank();
		//System.out.println(b1.balance);
		
		/*for calling the public method in the class bank*/
		b1.getvalue(2601);
		/*For calling setter method.By using this it will just updqate the value.
		 * For checking whether it got updated or not again we have to use get method.*/
		b1.setvalue(2000);
		b1.getvalue(2601);
		
		

	}

}
