package feb17;

public class Bank {
	
	/*If we create an another class we can easily access the data present in the main class Bank 
	if we are using public access-specifier.*/
	
	//public double balance=10000;
	
	/*So we are going to use Private access-specifier*/
	
	private double balance=10000;
	
	/*if we r making the variables as private, only that class methods can use it.
	 If u want to access the private variables of a class,create a public methods in that class 
	 and retrieve them using proper validation.
	 
	 For retrieving we are using getter methods.
	 getter methods are written with getMethodName()*/
	
	public void getvalue(int Pin)
	{
		if(Pin==2601)
		{
			System.out.println(balance);
		}
		else
		{
			System.out.println("Invalid Input");
		}
	}
	
	//Setter method
	/*It is used for updating the values */
	
	public void setvalue(int update)
	{
		balance=balance+update;
	}
	

}
