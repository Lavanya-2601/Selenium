package feb19;

public class dup1 {
	
	int x;
	
	public void set(int x)
	{
		this.x=x;
	}

}
