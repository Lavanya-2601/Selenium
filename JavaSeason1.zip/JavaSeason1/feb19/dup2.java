package feb19;

public class dup2 extends dup1 {

	int x;
	
	public void put(int x) 
	{
		this.x=x;
		
	}
	
	public void show()
	{
		System.out.println("x value is "+super.x);//This is used for printing the parent class variable value
		System.out.println("x value is "+x);//This is used for printing the child class variable value
		//these keywords will be used becz if there is a common variables present in the both parent and child classes.
	}
	
	
		
	
}
