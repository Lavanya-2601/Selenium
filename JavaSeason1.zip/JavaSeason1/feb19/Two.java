package feb19;

public class Two extends one{

	@Override
	public void m1(String name) 
	{
		 System.out.println("Hello "+name+" Gd Mrng");
	}
	

}
