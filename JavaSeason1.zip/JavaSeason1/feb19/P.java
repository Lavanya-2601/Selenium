package feb19;

public class P {
	
	int x=10;
	
	public void m1()
	{
		System.out.println("This is P's m1 method");
	}

}
