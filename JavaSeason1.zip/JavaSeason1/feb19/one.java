package feb19;

public class one {
	
	//Method Overriding
	//Here we are overriding the method of m1
	
	public void m1(String name) 
	{
		 System.out.println("Hey "+name+" Good Morning");
	}
	
	public void bye()
	{
		System.out.println("Bye");
	}

}
