package feb19;

public class Main {

	public static void main(String[] args) {
		
		
		/*Case-1
		one n1=new one();
		n1.m1("Lav");
		n1.bye();*/
		
		/*Case-2
		Two n1=new Two();
		n1.m1("Lav");
		n1.bye();*/
		
		//case-3
		one n1=new Two();
		n1.m1("Lav");
		n1.bye();
		
		/*case-4-This is not valid scenario.Where the parent object is not gng to store in the child reference.
		Two n1=new one();
		n1.m1("Lav");
		n1.bye();*/
		
		
		
	}

}
