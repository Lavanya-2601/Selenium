package feb19;

public class C extends P {
	
   int x=20;
	
	   public void m1()
	   {
		  System.out.println("This is C's m1 method");
	    }


}
