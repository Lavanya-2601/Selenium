package feb19;

public class DupMain {

	public static void main(String[] args) {
		

		dup2 d1=new dup2();
		/*d1.put(20); ->x value is 20
		  d1.show();*/
		
		
		/*For this x value is 0,becz for the reference object we didn't assigned any value.i.e,put value we didn't mentioned.
		   here x is refering to the reference object
		   If we want to refer the parent class variable then we have to use the keyword "Super" 
		   Now it will print the value as 40*/
		d1.set(40);
		d1.put(20);
		d1.show();
		
	}

}
