package feb19;

public class MethodOverridingDemo {

	public static void main(String[] args) {
		
		/*Case-1
		P p1=new P();
		System.out.println(p1.x);
		p1.m1();
		
		It will print the x=10 and P's m1 method*/
		
		
		/*Case-2
		C c1=new C();
		System.out.println(c1.x);
		c1.m1();
		
		It will print x=20 and C's m1 method*/
		
		//case-3
		
		P p1=new C();
		System.out.println(p1.x);
		p1.m1();
		
		/*It will print the C class m1 method and x value from the P's class(x=10).
		//This is because method is only getting overriding not the variable.
		So whatever the value present in the reference class(left side..i.e.,P) that value is getting printed.*/
		
		/*Case-4-Invalid
		C c1=new P();*/
		

	}

}
