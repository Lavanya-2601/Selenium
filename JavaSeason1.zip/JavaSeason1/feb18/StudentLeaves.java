package feb18;

public class StudentLeaves extends Student {
	
	int SickLeave, CasualLeave;
	
	
	public void setLeaves(int SickLeave, int CasualLeave)
	{
		this.SickLeave=SickLeave;
		this.CasualLeave=CasualLeave;
		
		
	}
	
	public void getLeaves()
	{
		System.out.println("Total no.of leaves taken by "+SName+ " is: "+(SickLeave+CasualLeave));
	}
	

}
