package feb18;

public class Addition extends Numbers {
	
	public void Add()
	{
		System.out.println("Addition of x and y is: "+(x+y));
	}
	
	
	
	

}
