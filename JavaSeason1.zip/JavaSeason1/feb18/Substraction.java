package feb18;

public class Substraction extends Numbers {
	
	public void Sub()
	{
		System.out.println("Substraction of x and y is: "+(x-y));
	}

}
