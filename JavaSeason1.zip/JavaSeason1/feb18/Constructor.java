package feb18;

public class Constructor {
	
	int hr,min,sec;
	
	//Constructor overloading
	
	
	//Default constructor
	/*public Constructor() {
		
		 hr=10;
		 min=20;
		 sec=30;
		
	}*/
	
	//Constructor with one argument
	public Constructor(int hr)
	{
		this.hr=hr;
		
	}
	public Constructor(int hr, int min)
	{
		this.hr=hr;
		this.min=min;
		
	}
	
	public void getCons()
	{
		System.out.format("%02d:%02d:%02d",hr,min,sec);
	}

}
