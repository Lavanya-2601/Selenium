package feb18;

public class NumbersMain extends Numbers {

	public static void main(String[] args) {
	
		//Numbers N1=new Numbers();
		//N1.setNameX(10);
		//N1.getNameX();
		//N1.setNameY(20);
		//N1.getNameY();
		
		//Calling Addition Method
		//Addition A1=new Addition();
		//Substraction A1=new Substraction();
		//Multiplication A1=new Multiplication();
		Division A1=new Division();
		A1.setNameX(20);
		A1.setNameY(10);
		//A1.Add();
		//A1.Sub();
		//A1.Mult();
		A1.Div();
		
		
		
	}

}
