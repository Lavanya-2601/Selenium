package feb18;

public class Multiplication extends Numbers {
	
	public void Mult()
	{
		System.out.println("Multiplication of x and y is: "+(x*y));
	}

}
