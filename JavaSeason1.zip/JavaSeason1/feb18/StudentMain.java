package feb18;

public class StudentMain {

	public static void main(String[] args) {
		
	StudentMarks s1=new StudentMarks();
	s1.setDetails(10, "Lavanya");
	s1.getDetails();
	
	//StudentLeaves data
	
	s1.setLeaves(3,5);
	s1.getLeaves();
	
	//StudentMarks details
	
    s1.setMarks(72,50,58);
    s1.getMarks();
    
	

	}

}
