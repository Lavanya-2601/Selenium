package feb18;

public class Division extends Numbers{
	
	public void Div()
	{
		System.out.println("Division of x and y is: "+(x/y));
	}

}
