package feb18;

public class ConsDemo1 {

	public static void main(String[] args) {
		
		
/*If there is no default constructor then we have to use the one which is having arguments.
In that case we have to write it as =new constructor(5);
If there is no constructor present in the class then JVM automatically creates a constructor.*/
		
		/*default constructor
		Constructor c1=new Constructor();*/
		
		Constructor c2=new Constructor(2,3);
		
		c2.getCons();
		
		
	}

}
