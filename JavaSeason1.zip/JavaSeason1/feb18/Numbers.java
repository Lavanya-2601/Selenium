package feb18;

public class Numbers {
	
 int x,y;
	
	public void setNameX(int x)
	{
		this.x=x;
	}
	
	public void setNameY(int y)
	{
		this.y=y;
	
	}
	
	public int getNameX()
	{
		return x;
	}
	public int getNameY()

	{
		return y;
	}
	/*public void getNameX()
	{
		System.out.println("The value of x is " +x);
		
	}
	public void getNameY()
	{
		System.out.println("The value of y is " +y);
	}*/

}
