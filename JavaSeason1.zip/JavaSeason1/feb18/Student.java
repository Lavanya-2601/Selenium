package feb18;

public class Student {
	
	//Inheritance 
	//StudentLeaves extends Student Class->It is a single inheritance
	//StudentMarks extends StudentLeaves & StudentLeaves extends Student->Multilevel Inheritance
	int rollNo;
	String SName;
	
	//Setters
	public void setDetails(int rollNo, String SName)
	{
		this.rollNo=rollNo;
		this.SName=SName;
	}
	//Getters
	public void getDetails()
	{
		System.out.println("Roll no is :"+rollNo);
		System.out.println("Student name is :"+SName);
	}
	
	
	

}
