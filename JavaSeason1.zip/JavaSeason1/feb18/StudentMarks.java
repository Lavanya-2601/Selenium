package feb18;

public class StudentMarks extends StudentLeaves {
	
	int Maths,Physics,Chemistry;
	
	public void setMarks(int Maths, int Physics, int Chemistry)

	{
		this.Maths=Maths;
		this.Physics=Physics;
		this.Chemistry=Chemistry;
		
		}
	
	public void getMarks()
	{
		System.out.println(SName+" Physics Marks is:"+Physics);
		System.out.println(SName+" Chemistry Marks is:"+Chemistry);
		System.out.println(SName+" Maths Marks is:"+Maths);
		
		
	}
}
