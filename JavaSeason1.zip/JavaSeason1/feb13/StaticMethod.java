package feb13;

public class StaticMethod {

	public static void main(String[] args) {
		
		/*the below method is static method 
		 So for calling static method we have to use classname.methodname(arguments)
		 */
		StaticMethod.method1(5);
		
		
	}

	public static void method1(int n)
	 {
		 int res=n*(n+1)/2;
		 System.out.println(res);
		 
	 }
}
