package feb13;

public class Person {
	
	String name;
	int age;
	long phoneNumber;
	
	
	

}
