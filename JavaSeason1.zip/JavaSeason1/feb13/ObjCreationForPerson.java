package feb13;

public class ObjCreationForPerson {

	public static void main(String[] args) {
		
		  Person p1 =new Person();
		  
		 
		 p1.name="Lav";
		 p1.age=26;
		 p1.phoneNumber=9381819415l;
		 
		 System.out.println(p1.name);
		  System.out.println(p1.age);
		  System.out.println(p1.phoneNumber);
		  
		 
		 
		 
		 
		
	}

}
