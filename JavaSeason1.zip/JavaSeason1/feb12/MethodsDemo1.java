package feb12;

public class MethodsDemo1 {

	public static void main(String[] args) {
		
		
		/*object creation
		ClassName ObjectName= new Classname();
		Objectname.MethodName(parameter);*/
		
		MethodsDemo1 obj=new MethodsDemo1();
		obj.m1(5);
      

	}
	
	public void m1(int n)
	{
	  int res=n=n*(n+1)/2;	
	  System.out.println(res);
	}

}
