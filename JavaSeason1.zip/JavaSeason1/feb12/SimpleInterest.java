package feb12;

public class SimpleInterest {

	public static void main(String[] args) {
		
	SimpleInterest obj1=new SimpleInterest();
	obj1.m1(2000,10.6,5);
	

	}

	public void m1(int p,double r,int t)
	{
		double S= (p*r*t)/100;
		System.out.println("The value of p is:" +p);
		System.out.println("The value of r is:"+r);
		System.out.println("The value of t is:"+t);
		System.out.println("Simple interest per" +t+ "years is:" +S);
				
	}
}

