package feb12;

public class MethodsDemo{

	public static void main(String[] args) {
		int n1=5;
		int result1=n1*(n1+1)/2;
		
		System.out.println(result1);
		
		int n2=10;
		int res2=n2*(n2+1)/2;
		
		System.out.println(res2);
		
		
		

	}
	
	}


