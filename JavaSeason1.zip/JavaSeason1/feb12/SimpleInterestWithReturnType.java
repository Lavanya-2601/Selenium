package feb12;

public class SimpleInterestWithReturnType {

	public static void main(String[] args) {
		
	SimpleInterestWithReturnType obj1=new SimpleInterestWithReturnType();
	System.out.println(obj1.m1(2000,10.6,5));
	

	}

	public double m1(int p,double r,int t)
	{
		//double S= (p*r*t)/100;
		//return S;
		//Instead of using above 2 lines we can directly write return the value
		
		return (p*r*t)/100;
	}
}

