package feb12;

public class DataTypeDemo1 {

	public static void main(String[] args) {
		/*byte stores only upto 127 range. 
	  If we give the number more than 127 it will ask us to change the byte to int*/
		
		byte a=127;
		
		/*short stores only upto 32768 range.
	If we give the number more than that it will ask us to change the short to byte*/
		short b= 32767;
		
		/*int stores only upto 2147483647 range.
		If we give the number more than that it will show the error as not in range*/
		int c=2147483647;
		
		/*long stores more than 2147483648 range.
		If we give the number more than that we have to write the "small/capital l/L"*/
		long d=2147483648l;
		long e=100;
		
		
		/*decimal values are considered as a double. 
		 * If we want to tell them that we need only 4 bytes of memory then we have to mention "f"*/
		float f=10.34f;
	
		//double 8 bytes of memory
		double g=3.145;
		
		boolean h=true;  //either true or false
		
		char i=97; //ASCII value of 97 is 'a'
		char j=65; //ASCII vlue of 65 is 'A'
		
		
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(g);
		System.out.println(h);
		System.out.println(i);
		System.out.println(j);
		
		

	}

}
