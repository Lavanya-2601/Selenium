package feb20;

public class AbstractMain {

	public static void main(String[] args) {
	
		
		/*We cannot create the object for the abstract class. 
		For using the methods in the abstract class we have to create a child class\ and in the 
		child class we have to implement the methods.
		Abs1 a1=new Abs1();*/
		
		//If there are more than one abstract class we have to implement all the abstract methods in the child class
		
		Abs2 a2=new Abs2();
		a2.method1(10);
		a2.greet();
		a2.method2();

	}

}
