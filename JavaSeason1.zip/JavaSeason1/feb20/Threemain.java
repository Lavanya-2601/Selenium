package feb20;

public class Threemain {

	public static void main(String[] args) {
		
		Two t=new Two();
		t.m1(10);
		System.out.println("Value of PI is "+One.PI);
		
	}

}
