package feb20;

public abstract class Abs1 {
	
	
	public abstract void method1(int n); //Idea with no implementation
	
	public void greet() //Idea and Implementation
	{
		System.out.println("Hey Good Morning");
	}
	
	public abstract void method2(); //Idea with no implementation
	
	

}
