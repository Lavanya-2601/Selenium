package feb20;

public interface One {
	
	/*Interfaces will have public static final constants and abstract methods.
	 *eventough if we didn't mentioned the access specifiers, access-modifiers and return type still it takes the public static final
	 *and the methods as abstract methods 
	 *
	 *
	 *
	 *Class One is an interface.
	 *Two class implements the class One
	 *Class ThreeMain is used for calling the above classes*/
	
	public static final double PI=3.14;
	
	 public void m1(int a);
	

}
