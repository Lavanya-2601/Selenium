package feb20;

public class Two implements One{

	@Override
	public void m1(int a) {
		System.out.println("Value of a is "+a);
		
	}
	
	
	
	

}
