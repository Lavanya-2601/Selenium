package feb20;

public class Abs2 extends Abs1{

	@Override
	public void method1(int n) 
	{
		
		System.out.println("This is an extended class of Abs1 "+n);
		
	}

	
	public void method2() 
	{
		//If there is no implementation atleast we have to write it like a method without any statements for clearing the error
		
	}
	
	

}
