package apr4;

public class breakDemo4 {

	public static void main(String[] args) {
	
		label:for(int i=0;i<=10;i++)
		{
			for(int j=0;j<=10;j++)
			{
				if(j==5)
				{
				   System.out.println("After loop..before break");
				   //using label it will break both the uinside and outside loops
					break label;
					
				}
			
				System.out.println(i+" "+j);
			}
			}
		
			

	}

}
