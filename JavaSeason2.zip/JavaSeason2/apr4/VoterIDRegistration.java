package apr4;

import java.util.Scanner;

public class VoterIDRegistration {

	public static void main(String[] args) {
		
		System.out.println("Enter age");
		Scanner input=new Scanner(System.in);
		int age=input.nextInt();
		
		if(age>=18)
		{
			System.out.println("Registration successful");
		}
		else
		{
			try
			{
			//here we r creating a new customized exception
				throw new InvalidAgeException();
			}
			
			catch(InvalidAgeException i)
			{
				System.out.println(i.getMessage());
			}
			
		}

		System.out.println("End of the program");
	}

}
