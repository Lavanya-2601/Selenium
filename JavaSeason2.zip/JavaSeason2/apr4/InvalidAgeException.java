package apr4;

public class InvalidAgeException extends RuntimeException{
	
	public InvalidAgeException()//default constructor
	{
		//for setting a mssage we have to use the parent calss(throwable class)
		//We can call the parent class using super keyword
		
		super("Invalid age..Not eligible for registration");
	}

	

	}


