package apr4;

public class ContinueDemo1 {

	public static void main(String[] args) {
		
		
		for(int i=0;i<=10;i++)
		{
			if(i==5)
			{
				//For continue, it will skip the current iteration
				continue;
				//After continue we cant execute any statements
				//System.out.println("hello");
			}
			System.out.println(i);
		}

	}

}
