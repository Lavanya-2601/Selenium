package apr4;

public class breakDemo3 {

	public static void main(String[] args) {
	
		for(int i=0;i<=10;i++)
		{
			for(int j=0;j<=10;j++)
			{
				if(j==5)
				{
					break;
					//after break statement we cant write any code.
					//It will throw a compilation error that it is unreachable
					//If it is a loop, break statement will bypass and comesout of the loop
					//If it is a switch,it will come out of the switch
				}
			
				System.out.println(i+" "+j);
			}
			}
		/*Here for i loop intial value =0 after that it will enter into j loop.
		 * here intial val=0. After completing all the values then only it will exit the loop and go back to i loop */
			

	}

}
