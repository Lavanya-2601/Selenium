package apr4;

import java.util.Scanner;

public class ExceptionDemo1 {

	public static void main(String[] args) {
		
		System.out.println("Enter divisor");
		Scanner input=new Scanner(System.in);
		int x=input.nextInt();
		
		
		System.out.println("Enter dividend");
		Scanner input1=new Scanner(System.in);
		int y=input1.nextInt();
		
		//System.out.println("Value is " +x/y);
		
		//For handling the exceptions we are using try catch blocks
		//Finally block is optional. It will exceute irrespective of the exception
		
		try
		{
			System.out.println("Value is " +x/y);
		}
		//we can also use multiple exceptions in the catch block using '|'
		//example:catch(ArithmeticException | IndexOutOfBoundException e)
		catch(ArithmeticException e)
		{
			System.out.println("got an exception still this block will executes");
		}
		finally
		{
			System.out.println("This is final block");
		}
		
		System.out.println("End of the program");

	}

}
