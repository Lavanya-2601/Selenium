package Mar5;

public class TwoDimensionalArray {

	public static void main(String[] args) {
		
		int[][] a= new int[2][4];
		
		//a.length is a number of rows
		//a[i] is a no.of columns
		System.out.println(a.length);//2
		System.out.println(a[0].length);//4
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		
		a[0][0]=1;
		a[0][1]=2;
		a[0][2]=3;
		a[0][3]=4;
		System.out.println(a.length);//2
		System.out.println(a[0].length);
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				a[1][j]=a[0][j]*a[0][j];
				
				System.out.print(a[i][j]+ " ");
			}
			System.out.println();
			
		}
		
		
		
		
		

	}

}
