package Mar5;

import java.util.ArrayList;

public class ArrayListDemo1 {

	public static void main(String[] args) {
		
		//This will accept all types of data types.If we want to get only the particular data then we have to go for generic topic
		//default capacity of arraylist is 10
		//Here "<>"value should be written inside it.
		
		ArrayList<String> al=new ArrayList<String>();
		
		System.out.println(al.size());
		
		//al.add(10);
		al.add("FLM");
		//al.add('c');
		//al.add(20.22);
		
		//size() represents the number of values present
		System.out.println(al.size());
		
		//For retrieving the exact values
		for(int i=0;i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		
		//we can also use foreach loop if there are any generic datatype present
		for(String temp:al)
		{
			System.out.println(temp);
		}

		//Contains is used to check whether the value is present in it or not- true/false
		 System.out.println(al.contains("FLM"));
	}

}
