package Mar5;
public class ArraysDemo2 {

	public static void main(String[] args) {
		
		//one dimensional array
		
		//This is an integer so we will get default value as "0".
		//If it is a string we wil get default value as "Null"
		String[] a=new String[10];
		
		//int[] a=new int[10];
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
			
			
		}
		
		//These values will get assigned to the following array
		// a[3]=200;
	     //a[8]=700;  
	     
	     a[3]="Lav";
	     a[7]="Div";
	     
		//for(int temp:a)
	     for(String temp:a)
		{
			//System.out.println(temp);//It will print in diff lines
	    	 System.out.print(temp+"\t");//\t is for getting tab space
			
		}
		
		
	    
       
	}

}
