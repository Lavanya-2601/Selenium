package Mar3;

import java.util.Scanner;

public class IfElseDemo4 {

	public static void main(String[] args) {
		
		//Printing of DOB 26-1-1999 in the format 26-JAN-1999
		
		System.out.println("Enter Date");
		
		Scanner scn=new Scanner(System.in);
		int Date=scn.nextInt();
		
		System.out.println("Enter Month");
		int Month=scn.nextInt();
		

		System.out.println("Enter Year");
		int Year=scn.nextInt();
		
		//int x=10 just like we are defining the string variable
		
		String month=null;
		
		
		if(Month==1)
		{
			month="Jan";
		}
		
		else if (Month==2)
		{
			month="Feb";
		}
		else if (Month==3)
		{
			month="Mar";
		}
		else if (Month==4)
		{
			month="APR";
		}
		else if (Month==5)
		{
			month="MAY";
		}
		else if (Month==6)
		{
			month="JUN";
		}
		else if (Month==7)
		{
			month="JUL";
		}
		
		System.out.format("Date of Birth is : %02d-%s-%04d",Date, Month,Year);
	}
	
	
		
		
	
		

	}

