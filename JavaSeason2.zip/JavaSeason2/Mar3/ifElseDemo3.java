package Mar3;

import java.util.Scanner;

public class ifElseDemo3 {

	public static void main(String[] args) {
		
		//<=30000 20%Hike
		//>30000 and <=60000 30%Hike
		//>60000 40%
		System.out.println("Enter number");
		Scanner scn=new Scanner(System.in);
		int sal=scn.nextInt();
		
		System.out.println("Enter Department");
		String dept=scn.next();
		
		//nextint() is for integers
		//next() is for string
		
		if(dept.equals("Non-IT"))
		{
		if(sal<30000)
		{
			sal=sal+(sal*10)/100;
			
		}
		else if(sal>30000 && sal<60000)
		{
			sal=sal+(sal*20)/100;
		}
		else
		{
			sal=sal+(sal*30)/100;
		}
		}
		else
		{
			if(sal<30000)
			{
				sal=sal+(sal*20)/100;
				
			}
			else if(sal>30000 && sal<60000)
			{
				sal=sal+(sal*30)/100;
			}
			else
			{
				sal=sal+(sal*40)/100;
			}
			}
		
		System.out.println("Net Salary:" +sal);
	}

	}


