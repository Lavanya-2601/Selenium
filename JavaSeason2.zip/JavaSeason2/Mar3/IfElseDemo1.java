package Mar3;

import java.util.Scanner;

public class IfElseDemo1 {

	public static void main(String[] args) {
		
		int sal=30000;
	
		
		//sal>=30000 20percent otherwise 30percent
		
		System.out.println("Enter number");
		Scanner scn=new Scanner(System.in);
		int n=scn.nextInt();
		
		//int res=sal<=30000?sal=sal+(sal*20)/100:sal+((sal*30)/100);
		//System.out.println("Net Salary:"+res);
		
		
		if(sal<=30000)
		{
			sal=sal+((sal*20)/100);
		}
		else
		{
			sal=sal+((sal*30)/100);
		}
		
		System.out.println("Net Salary "+sal);
	}

}
