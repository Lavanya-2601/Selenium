package Mar3;

import java.util.Scanner;

public class TernaryOperators {

	public static void main(String[] args) {
		
		System.out.println("Enter number");
		
		Scanner scn=new Scanner(System.in);
		int n=scn.nextInt();
		
		
		System.out.println((n>=0?"+ve":"-ve"));
		
		/*if(n>=0)
		{
			System.out.println("+ve");
		}
		else
		{
			System.out.println("-ve");
		}*/
}
		
		
		

	}


