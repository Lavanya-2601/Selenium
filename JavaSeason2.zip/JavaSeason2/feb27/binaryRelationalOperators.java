package feb27;

public class binaryRelationalOperators {

	public static void main(String[] args) {
		
		//Operators are >,<,>=,<=,!=,==
		int x=20, y=10;
		
		//Comparision between two things
		//Results will be in the true/flase format
		
		System.out.println(x>y);
		System.out.println(x<y);
		System.out.println(x>=y);
		System.out.println(x<=y);
		System.out.println(x==y);
	    System.out.println(x!=y);
		

	}

}
