package feb27;

public class binaryAssignmentOperators {

	public static void main(String[] args) {
		
		//Operators are =,+=,-=,*=,/=,%=,>>=,<<=
		
	int x=20;
	//x+=10;
	 x-=10;
		
		System.out.println(x);//x=x+y
		
	}

}
