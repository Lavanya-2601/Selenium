
package feb27;

public class unaryOperators {

	public static void main(String[] args) {
		
		//Unary Operators
		
	int x=20;
	
	System.out.println(x);
	System.out.println(x++);//Here the value will be 20 only.After this expression it will get increment to 21
	System.out.println(x--);//So here the value will be 21.After running the exp val will get updated as 20 
	System.out.println(++x);//Here the value will the incremented before running the exp.So it will give the updated value as 21
	System.out.println(--x);

	}

}
