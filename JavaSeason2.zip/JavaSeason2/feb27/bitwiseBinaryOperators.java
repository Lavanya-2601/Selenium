package feb27;

public class bitwiseBinaryOperators {

	public static void main(String[] args) {
		
		//Operators are &,|,>>,<<,>>>,~
		
       int x=3, y=4;
		
		System.out.println(x&y);
		System.out.println(x|y);
		//System.out.println(xy);
		System.out.println(x>>y);//RightShift
		System.out.println(x<<y);//Left Shift
		System.out.println(x>>>y);// Unary Right Shift
		
		

	}

}
