package feb27;

import java.util.Scanner;

public class binaryLogicalOperators {

	public static void main(String[] args) {
		
		//Operators are &&,||,!
		
		System.out.println("Enter user input");
		
		Scanner scn=new Scanner(System.in);
		 int x= scn.nextInt();//We are passing integer so we are using nextint() method
		 
		 //X between 0 and 10
		 
		 if(x>=0 && x<=10) //if(x>=0 || x<=10)  if(!(x>=0))
		 {
			 System.out.println("Value lies in between the range");
		 }
		 else
		 {
			 System.out.println("Not in range");
		 }
		 
		 
		
		
		
	}

}
