package feb27;

public class binaryArithmeticOperators {

	public static void main(String[] args) {
		
		//Operators are +,-,*,/,%
		
		int x=20, y=10;
		
		System.out.println(x+y);
		System.out.println(x-y);
		System.out.println(x*y);
		System.out.println(x/y);//Gives the quotient value
		System.out.println(x%y);//Gives the remainder value
		
		
	}

}
