package mar4;

public class forLoop1 {

	public static void main(String[] args) {
		
		//System.out.println("Hello World");
		//System.out.println("Hello World");
		//System.out.println("Hello World");
		
		//Instead of writing the same statements in multiple times we can use for loop
		
		for(int i=1;i<=5;i++)
		{
			System.out.println("Hello World");
		}

	}

}
/*int i=1;
while(i<=5)
{
System.out.println("Hello World");
i++;
}*/