package mar4;

public class arrayDemo1 {

	public static void main(String[] args) {
		
		//methods1
		
		int[] a = {10,20,30,40,50};
		System.out.println(a.length);
		
		System.out.println(a[1]);
		
		//using for loop
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
			
		}
		
		//using for each loop
		//Syntax-for(datatype refrencevariable:arrayname)
		for(int b:a)
		{
			System.out.println(b);
			
		}

	}

}
