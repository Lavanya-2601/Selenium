package mar4;

public class forLoop2 {

	public static void main(String[] args) {
		
		forLoop2.natSum(10);
	
		
		
		//Sum of n natural numbers
		//Natural numbers starts from 1
		//Whole numbers starts from 0
	}
	
		public static void natSum(int num)
	    {
			int res=0;
		
		for (int i=1;i<=num;i++)
		{
			res=res+i;
		}
		
		System.out.println("Sum of "+num + " natural numbers is " +res);

	}

}
	
