package mar4;

import java.util.Scanner;

public class whileLoop2 {

	public static void main(String[] args) {
		
		
	  boolean status=true;
		while(status) {
			
			System.out.println("Enter some character");
			Scanner scn=new Scanner(System.in);
			char ch=scn.next().charAt(0);
			if(ch!='x')
			{
				System.out.println("You have entered "+ch);
				status=true;
			}
			else
			{
				System.out.println("Existing the loop");
				status=false;
			}
			
		}
		
	}
	

}
