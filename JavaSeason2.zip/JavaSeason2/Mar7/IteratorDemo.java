package Mar7;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorDemo {

	public static void main(String[] args) {
	
		ArrayList<String> al= new ArrayList<String>();
		
		al.add("FLM");
		al.add("Java");
		al.add("Python");
		al.add("Selenium");
		
		//Creating an iterator for the String array list
		 Iterator<String> it= al.iterator();
		 
		 /*Iterator is having 2 method
		  * hasNext() and next()
		  * hasNext() is used to know if there is any element present in the next line
		  * next() is used to retrive that element */
		 
		 while(it.hasNext())
		 {
			 System.out.println(it.next());
		 }
		
		

	}

}
