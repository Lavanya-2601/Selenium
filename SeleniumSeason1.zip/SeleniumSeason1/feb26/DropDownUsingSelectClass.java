package feb26;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DropDownUsingSelectClass {

	public static void main(String[] args) {
		
		//Dropdown using Select method methods
		
		
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();

		driver.get("https://www.amazon.com/");
		driver.manage().window().maximize();
		
		/*Select class is present in a org.openqa.selenium.support.ui
		There is a parameterized constructor so we have to create a object with parameter and
		return type should be WebElement*/
		
		/*Method1
		
		WebElement e1=driver.findElement(By.id("searchDropdownBox"));
		 
		Select s1=new Select(e1);
		
		//First method selectByByIndex(int)
		s1.selectByIndex(5);
		
		//Second method selectByValue(String)
				s1.selectByValue("search-alias=stripbooks-intl-ship");
		
		//Method three SelectByVisibleText(String)
		s1.selectByVisibleText("Books");*/
		
		
		//Method2
		new Select(driver.findElement(By.id("searchDropdownBox"))).selectByIndex(5);
		new Select(driver.findElement(By.id("searchDropdownBox"))).selectByValue("search-alias=stripbooks-intl-ship");
		new Select(driver.findElement(By.id("searchDropdownBox"))).selectByVisibleText("Books");
		
		driver.quit();
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
