package feb26;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class facebookDropDownConventionalWay {

	public static void main(String[] args) {
		
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();
		
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("Create new account")).click();
		
		//driver.findElement(By.xpath("//*[@id=\"u_0_0_XS\"]")).click();
		/*driver.findElement(By.id("day")).sendKeys("26");
		driver.findElement(By.id("month")).sendKeys("January");
		driver.findElement(By.id("year")).sendKeys("1999");*/
		
		WebElement d1=driver.findElement(By.id("day"));
		Select S1=new Select(d1);
		S1.selectByIndex(25);
		
		WebElement m1=driver.findElement(By.id("month"));
		Select S2=new Select(m1);
		//S2.selectByValue("1");//we have to take the value of attribute value from the dropdown
		S2.selectByVisibleText("Jan");
		
		
		WebElement y1=driver.findElement(By.id("year"));
		Select S3=new Select(y1);
		S3.selectByValue("1999");
		
		
		
	}

}