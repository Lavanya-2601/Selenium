package feb26;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class methodsOfWebElements {

	public static void main(String[] args) {
		

		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();
		
		//findelemets(by)
		
	driver.get("https://adactinhotelapp.com/");
	
	//sendkeys
	
	  driver.findElementById("username").sendKeys("lavanya2601");
	    driver.findElementById("password").sendKeys("lavanya26");
	    
	    driver.manage().window().maximize();
	    
	    //isdisplayed
	    System.out.println(driver.findElement(By.id("username_span")).isDisplayed());
	    
	    //clear()
	    
	    driver.findElementById("username").clear();	 
	    
	    //click
	    driver.findElementById("login").click();
	    
	    //gettext-for getting any value
	   System.out.println(driver.findElement(By.id("username_span")).getText());
	   
	   //getattribute-case1for getting the attribute values
	   System.out.println(driver.findElement(By.id("username_span")).getAttribute("class"));
	 //getattribute-case2 if there is no attribute
	   System.out.println(driver.findElement(By.id("username_span")).getAttribute("name"));
	   
	   //getcssvalue
	   
	  System.out.println(driver.findElement(By.className("build_title")).getCssValue("color"));
	   
	   //tagname
	  System.out.println(driver.findElement(By.id("username")).getTagName());
	    
	  //isdisplayed
	  System.out.println(driver.findElement(By.id("username_span")).isDisplayed());
	    //quit
	    driver.quit();
	    

	}



	}


