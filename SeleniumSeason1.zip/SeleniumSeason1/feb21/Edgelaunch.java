package feb21;

import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Edgelaunch {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.edge.driver","C:\\Selenium Softwares\\Automation Testing\\edgedriver_win64\\msedgedriver.exe");
		
		//WebDriverManager.edgedriver().setup();
		new EdgeDriver();
		
	}

}
