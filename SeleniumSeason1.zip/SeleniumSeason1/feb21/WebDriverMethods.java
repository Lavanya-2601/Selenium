package feb21;

import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebDriverMethods {

	public static void main(String[] args) {
		
		//launching the edge browser
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();
		
		//get(string)Opening a website with Url
		
		driver.get("https://facebook.com");
	
		
		//getTitle()It is used to get the title of the page/website
		
		System.out.println(driver.getTitle());
		
		//getcurrenturl
		System.out.println(driver.getCurrentUrl());
		
		//manage()this will helps in managing the window sizes,cookies,etc..
		driver.manage().window().maximize();
		
		//getpagesource()-this will give the html code of that particular page
		System.out.println(driver.getPageSource());
		
		//getWindowHandle-this will provide us the window id in which webdriver focus is
		System.out.println(driver.getWindowHandle());
		
		//Quit();
		driver.quit();
		

		//close()It will close the window/tab on which webdriver focus is
		
		//driver.close();
		
	}
	

}
