package feb21;

import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ChromeLaunch {

	public static void main(String[] args) {
		
		/*1st method

     System.setProperty("webdriver.chrome.driver","C:\\Users\\sivada.lavanya\\Downloads\\Automation Testing\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
     new ChromeDriver();*/
		
		/*2nd method
		 * Copy the driver path link and paste it on the project.*/
		 new ChromeDriver(); 
		
		/*3rd method using web driver manager
		
		WebDriverManager.chromedriver().setup();
     new ChromeDriver();*/
	}

}
