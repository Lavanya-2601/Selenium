package feb24;

import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class webDriverMethod3 {

	public static void main(String[] args) {
		
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();
		
		//findelemets(by)
		
	driver.get("https://adactinhotelapp.com/");
		
    driver.findElementById("username").sendKeys("lavanya2601");
    driver.findElementById("password").sendKeys("lavanya26");
    
    driver.findElementById("login").click();
    
    driver.quit();
	}

}
