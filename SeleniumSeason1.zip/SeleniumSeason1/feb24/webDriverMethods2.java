package feb24;

import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class webDriverMethods2 {

	public static void main(String[] args) throws InterruptedException {
	
		//Navigation
		
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();
		
		//get
		driver.get("https://adactinhotelapp.com/");
		driver.manage().window().maximize();
		
		Thread.sleep(3000);
		
		//forward
		driver.navigate().forward();
		
		driver.get("https://adactinhotelapp.com/Register.php");
		Thread.sleep(3000);
		
		//refresh
		driver.navigate().refresh();
		Thread.sleep(3000);
		
		
		//back
		driver.navigate().back();
		
		//Quit
		driver.quit();
		
		
	}

}
