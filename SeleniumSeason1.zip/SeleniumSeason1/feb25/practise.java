package feb25;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class practise {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.edgedriver().setup();
		EdgeDriver driver=new EdgeDriver();
		
		//PAGE LEVEL METHODS
		//get(string)
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		Thread.sleep(3000);
		
		driver.get("https://adactinhotelapp.com/");
		//navigate()
		
		driver.navigate().back();
				driver.navigate().forward();
		driver.navigate().back();
		
		//manage
		driver.manage().window().maximize();
		
		//getTitle()
		System.out.println(driver.getTitle());
		
		//getcurrentURL()
		
		System.out.println(driver.getCurrentUrl());
		
		//getwindowhandler()
		
		System.out.println(driver.getWindowHandle());
		
		driver.findElement(By.linkText("OrangeHRM, Inc")).click();
		//getwindowhandlers()
		System.out.println(driver.getWindowHandles());
		Thread.sleep(3000);
		
		//navigate()
		driver.navigate().refresh();
		
		
		
		
		//Quit()
		driver.quit();
		
		//close()
		
		
		//switchTo()
		
		
		
		
		
		

	}

}
